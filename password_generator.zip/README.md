# 🛠️ GitHub Password Generator

A simple Python script to generate strong, secure passwords using the `secrets` module — ideal for GitHub or any secure login.

## 🔒 Features

- Cryptographically secure password generation
- Includes letters, numbers, and special characters
- Customizable password length

## 🚀 Usage

1. Clone this repo or download the script.

2. Run the script:

```bash
python password_generator.py
```

3. Example output:

```
Generated password: V#e9!rKm4^q2Wz@pL8t%
```

4. Customize length (optional):

Edit the line in the script:

```python
password = generate_password(length=30)
```

## 📄 Code

```python
import secrets
import string

def generate_password(length=20):
    characters = string.ascii_letters + string.digits + string.punctuation
    password = ''.join(secrets.choice(characters) for _ in range(length))
    return password

# Example usage
if __name__ == "__main__":
    print(f"Generated password: {generate_password()}")
```

## 🧠 Note

Always store passwords securely (e.g., password managers). This script does not store or transmit generated passwords.